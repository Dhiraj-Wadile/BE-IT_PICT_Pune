import java.rmi.*;
import java.math.BigInteger; // Import BigInteger for large number handling

public interface AddServerIntf extends Remote {
    // Method declaration for calculating factorial
    BigInteger fct(int d1) throws RemoteException;
}

