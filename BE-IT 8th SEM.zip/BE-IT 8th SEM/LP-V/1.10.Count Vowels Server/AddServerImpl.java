import java.rmi.*;
import java.rmi.server.*;

// Class that implements the remote interface
public class AddServerImpl extends UnicastRemoteObject implements AddServerIntf {

    // Constructor
    public AddServerImpl() throws RemoteException {
    }

    // Implement method declared in the interface
    public int cvwl(String c) throws RemoteException {
        int vc = 0;
        // Loop through each character in the string
        for (int i = 0; i < c.length(); i++) {
            char ch = c.charAt(i);
            // Check if the character is a vowel (case-insensitive)
            if ("aeiouAEIOU".indexOf(ch) != -1) {
                vc++;
            }
        }
        return vc;
    }
}

