import java.rmi.*;

public class AddClient {
    public static void main(String args[]) { 
        try {
            // Ensure that we have at least 2 arguments: host and name
            if (args.length < 2) {
                System.out.println("Usage: java AddClient <host> <name>");
                return;
            }

            // Get reference to the remote object
            String addServerURL = "rmi://" + args[0] + "/AddServer"; 
            AddServerIntf addServerIntf = (AddServerIntf) Naming.lookup(addServerURL);

            // args[1] contains the full name
            String fullName = args[1]; 

            // Call remote method 'hel' and display the greeting
            System.out.println(":) " + addServerIntf.hel(fullName));
        } 
        catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}

