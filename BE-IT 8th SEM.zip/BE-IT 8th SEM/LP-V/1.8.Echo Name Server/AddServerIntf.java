import java.rmi.*;

public interface AddServerIntf extends Remote { 
    // Method declaration 
    String hel(String d1) throws RemoteException;
}

