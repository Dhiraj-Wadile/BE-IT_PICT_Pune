import java.rmi.*;
import java.rmi.server.*;

// Class that implements the remote interface
public class AddServerImpl extends UnicastRemoteObject implements AddServerIntf {

    // Constructor
    public AddServerImpl() throws RemoteException {
        super();
    }

    // Implement method declared in the interface
    public String hel(String c) throws RemoteException {
        // Check if the input string is empty
        if (c == null || c.trim().isEmpty()) {
            return "Hello, World!"; // Default greeting if no name is provided
        } else {
            return "Hello, " + c + "!"; // Greet the person with their full input (name or sentence)
        }
    }
}

