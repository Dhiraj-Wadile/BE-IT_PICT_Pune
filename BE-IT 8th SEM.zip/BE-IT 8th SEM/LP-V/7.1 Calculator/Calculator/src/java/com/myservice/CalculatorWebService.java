/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myservice;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author nahus
 */
@WebService(serviceName = "CalculatorWebService")
public class CalculatorWebService {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addition")
    public Double addition(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        //TODO write your implementation code here:
        return num1+num2;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "subtraction")
    public Double subtraction(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        //TODO write your implementation code here:
        return num1-num2;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "multiplication")
    public Double multiplication(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        //TODO write your implementation code here:
        return num1*num2;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "division")
    public Double division(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        //TODO write your implementation code here:
        return num1/num2;
    }

    /**
     * This is a sample web service operation
     */
    
}
